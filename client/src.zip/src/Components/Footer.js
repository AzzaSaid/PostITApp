const Footer = () => {
  return (
    <footer className="footer">
      <div>Azza Said Al-Taiwani|©2024|PostIT|All Rights Reserved.</div>
    </footer>
  );
};

export default Footer;
